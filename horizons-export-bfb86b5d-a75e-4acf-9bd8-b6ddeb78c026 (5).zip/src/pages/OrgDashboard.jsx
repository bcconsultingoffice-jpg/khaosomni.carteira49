import React from 'react';
import RestaurantDashboard from './RestaurantDashboard';

const OrgDashboard = () => {
  return <RestaurantDashboard />;
};

export default OrgDashboard;