import React from 'react';
import SuperadminDashboard from './SuperadminDashboard';

const AdminDashboard = () => {
  return <SuperadminDashboard />;
};

export default AdminDashboard;