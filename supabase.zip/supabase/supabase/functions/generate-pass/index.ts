﻿import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { Template } from "npm:@walletpass/pass-js";

serve(async (req) => {
  try {
    // ✅ Caminho correto para a pasta template no ambiente do Supabase
    const templateUrl = new URL("./template", import.meta.url);

    // 📦 Carrega o template do passe
    const template = await Template.load(templateUrl, Deno.env.get("SIGNER_SECRET"));

    // 🔐 Carrega certificados
    const certPath = new URL("./keys/certificate.pem", import.meta.url);
    const keyPath = new URL("./keys/private.key", import.meta.url);
    const wwdrPath = new URL("./keys/AppleWWDR.pem", import.meta.url);

    const cert = await Deno.readTextFile(certPath);
    const key = await Deno.readTextFile(keyPath);
    const wwdr = await Deno.readTextFile(wwdrPath);

    await template.loadCertificate(certPath, Deno.env.get("SIGNER_SECRET"));
    template.setPrivateKey(key);
    template.setWwdrCertificate(wwdr);

    // 🆕 Cria um passe
    const pass = template.createPass({
      serialNumber: crypto.randomUUID(),
      description: "Exemplo Supabase Wallet Pass",
      organizationName: "Minha Empresa",
      passTypeIdentifier: "pass.com.seuprojeto",
      teamIdentifier: "ABCDE12345", // seu Team ID da Apple Developer
    });

    // ➕ Campos personalizados
    pass.primaryFields.add({
      key: "nome",
      label: "Nome",
      value: "Usuário Teste",
    });

    // 📦 Gera o arquivo final
    const buffer = await pass.asBuffer();

    return new Response(buffer, {
      headers: {
        "Content-Type": "application/vnd.apple.pkpass",
        "Content-Disposition": "attachment; filename=pass.pkpass",
      },
    });
  } catch (err) {
    console.error("❌ Erro ao gerar passe:", err);
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
});
