


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


CREATE SCHEMA IF NOT EXISTS "public";


ALTER SCHEMA "public" OWNER TO "pg_database_owner";


COMMENT ON SCHEMA "public" IS 'standard public schema';



CREATE OR REPLACE FUNCTION "public"."fn_find_user_id"("p_email" "text") RETURNS "uuid"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
declare
  uid uuid;
  is_admin boolean;
begin
  select public.is_superadmin() into is_admin;
  if not is_admin then
    raise exception 'not_allowed';
  end if;

  select u.id into uid
  from auth.users u
  where u.email = p_email
  limit 1;

  return uid;
end $$;


ALTER FUNCTION "public"."fn_find_user_id"("p_email" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."fn_get_global_kpis"() RETURNS TABLE("projects" integer, "customers" integer, "visits" integer, "rewards_unlocked" integer)
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  select
    (select count(*) from public.projects)::integer as projects,
    (select count(distinct c.id) from public.customers c)::integer as customers,
    (select count(*) from public.events e where e.type='visit')::integer as visits,
    (select count(*) from public.events e where e.type='reward_unlocked')::integer as rewards_unlocked;
$$;


ALTER FUNCTION "public"."fn_get_global_kpis"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."fn_get_global_kpis_timeseries"("p_months" integer) RETURNS TABLE("month" "date", "visits" integer, "rewards" integer)
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  with months as (
    select date_trunc('month', (now() - (i || ' months')::interval))::date as m
    from generate_series(0, p_months-1) i
  )
  select m.m as month,
    coalesce( (select count(*) from public.events e
              where e.type='visit'
                and date_trunc('month', e.at)=m.m), 0)::integer as visits,
    coalesce( (select count(*) from public.events e
              where e.type='reward_unlocked'
                and date_trunc('month', e.at)=m.m), 0)::integer as rewards
  from months m
  order by m.m;
$$;


ALTER FUNCTION "public"."fn_get_global_kpis_timeseries"("p_months" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."fn_get_project_analytics"("p_project_id" "uuid", "p_start_date" timestamp with time zone, "p_end_date" timestamp with time zone) RETURNS "jsonb"
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_member BOOLEAN;
  v_is_superadmin BOOLEAN;
  result JSONB;
BEGIN
  SELECT is_member_of(p_project_id) INTO v_is_member;
  SELECT is_superadmin() INTO v_is_superadmin;

  IF NOT v_is_member AND NOT v_is_superadmin THEN
    RAISE EXCEPTION 'Acesso negado.';
  END IF;

  WITH visits_in_period AS (
    SELECT
      id,
      at AS visited_at
    FROM public.events
    WHERE
      project_id = p_project_id AND
      type = 'visit' AND
      at >= p_start_date AND
      at <= p_end_date
  ),
  kpis AS (
    SELECT
      COUNT(DISTINCT customer_id) AS active_customers,
      COUNT(*) AS visits_this_cycle,
      (SELECT COUNT(*) FROM public.events e WHERE e.project_id = p_project_id AND e.type = 'reward_unlocked' AND e.at >= p_start_date AND e.at <= p_end_date) AS rewards_unlocked,
      (SELECT COUNT(*) FROM public.wallet_links wl WHERE wl.project_id = p_project_id AND wl.created_at >= p_start_date AND wl.created_at <= p_end_date) AS wallet_linked
    FROM public.events
    WHERE project_id = p_project_id AND type = 'visit' AND at >= p_start_date AND at <= p_end_date
  ),
  visits_by_dow AS (
    SELECT
      -- TO_CHAR is locale-dependent, EXTRACT is universal. 1=Sun, 2=Mon...
      EXTRACT(DOW FROM visited_at) AS day_of_week_num,
      COUNT(*) AS visit_count
    FROM visits_in_period
    GROUP BY day_of_week_num
  ),
  visits_by_dom AS (
    SELECT
      EXTRACT(DAY FROM visited_at) AS day_of_month,
      COUNT(*) AS visit_count
    FROM visits_in_period
    GROUP BY day_of_month
  ),
  visits_by_hod AS (
    SELECT
      EXTRACT(HOUR FROM visited_at) AS hour_of_day,
      COUNT(*) AS visit_count
    FROM visits_in_period
    GROUP BY hour_of_day
  )
  SELECT jsonb_build_object(
    'kpis', (SELECT to_jsonb(kpis) FROM kpis),
    'by_day_of_week', COALESCE((SELECT jsonb_agg(to_jsonb(v)) FROM visits_by_dow v), '[]'::jsonb),
    'by_day_of_month', COALESCE((SELECT jsonb_agg(to_jsonb(v)) FROM visits_by_dom v), '[]'::jsonb),
    'by_hour_of_day', COALESCE((SELECT jsonb_agg(to_jsonb(v)) FROM visits_by_hod v), '[]'::jsonb)
  ) INTO result;

  RETURN result;
END;
$$;


ALTER FUNCTION "public"."fn_get_project_analytics"("p_project_id" "uuid", "p_start_date" timestamp with time zone, "p_end_date" timestamp with time zone) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."fn_get_project_kpis"("p_project_id" "uuid") RETURNS TABLE("active_customers" bigint, "visits_this_cycle" bigint, "rewards_unlocked" bigint, "wallet_linked" bigint)
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT
    (SELECT count(DISTINCT c.id) FROM public.customers c WHERE c.project_id = p_project_id) as active_customers,
    (SELECT count(v.*) FROM public.visits v WHERE v.project_id = p_project_id AND v.created_at >= (CURRENT_DATE - INTERVAL '30 days')) as visits_this_cycle,
    (SELECT count(e.*) FROM public.events e WHERE e.project_id = p_project_id AND e.type = 'reward_unlocked') as rewards_unlocked,
    (SELECT count(wl.*) FROM public.wallet_links wl WHERE wl.project_id = p_project_id) as wallet_linked;
$$;


ALTER FUNCTION "public"."fn_get_project_kpis"("p_project_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."fn_get_project_kpis_timeseries"("p_project_id" "uuid", "p_months" integer) RETURNS TABLE("month" "date", "visits" integer, "rewards_unlocked" integer, "wallet_linked" integer)
    LANGUAGE "sql" STABLE
    AS $$
  with months as (
    select date_trunc('month', (now() - (i || ' months')::interval))::date as m
    from generate_series(0, p_months-1) i
  )
  select m.m as month,
    coalesce( (select count(*) from public.events e
               where e.project_id=p_project_id and e.type='visit'
                 and date_trunc('month', e.at)=m.m), 0)::integer as visits,
    coalesce( (select count(*) from public.events e
               where e.project_id=p_project_id and e.type='reward_unlocked'
                 and date_trunc('month', e.at)=m.m), 0)::integer as rewards_unlocked,
    coalesce( (select count(*) from public.events e
               where e.project_id=p_project_id and e.type='wallet_linked'
                 and date_trunc('month', e.at)=m.m), 0)::integer as wallet_linked
  from months m
  order by m.m;
$$;


ALTER FUNCTION "public"."fn_get_project_kpis_timeseries"("p_project_id" "uuid", "p_months" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."fn_get_project_kpis_v2"("p_project_id" "uuid") RETURNS TABLE("active_customers" integer, "visits_this_cycle" integer, "rewards_unlocked" integer)
    LANGUAGE "sql" STABLE
    AS $$
  SELECT
    (SELECT COUNT(*) FROM public.customers c WHERE c.project_id = p_project_id) AS active_customers,
    (SELECT COUNT(*) FROM public.visits v WHERE v.project_id = p_project_id AND v.created_at >= (CURRENT_DATE - INTERVAL '30 days')) AS visits_this_cycle,
    (SELECT COUNT(*) FROM public.loyalty_states l WHERE l.project_id = p_project_id AND l.points >= 10) AS rewards_unlocked;
$$;


ALTER FUNCTION "public"."fn_get_project_kpis_v2"("p_project_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."fn_get_stats"("p_project" "uuid") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
declare
  v_is_admin boolean;
  v_total int;
  v_perto int;
  v_completos int;
begin
  select public.is_superadmin() into v_is_admin;
  if not v_is_admin and not public.is_member_of(p_project) then
    raise exception 'not_allowed';
  end if;

  select count(*) into v_total
  from public.customers c
  where c.project_id = p_project;

  select count(*) into v_completos
  from public.loyalty_states s
  where s.project_id = p_project and s.points >= 10;

  select count(*) into v_perto
  from public.loyalty_states s
  where s.project_id = p_project and s.points between 7 and 9;

  return jsonb_build_object(
    'totalClientes', coalesce(v_total,0),
    'pertoDeGanhar', coalesce(v_perto,0),
    'completos', coalesce(v_completos,0)
  );
end $$;


ALTER FUNCTION "public"."fn_get_stats"("p_project" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."fn_get_stats_all"() RETURNS TABLE("project_id" "uuid", "name" "text", "totalclientes" bigint, "pertodeganhar" bigint, "completos" bigint)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
declare r record;
begin
  for r in
    select p.id, coalesce(p.name, '(sem nome)') as name
    from public.projects p
    where public.is_superadmin()
       or exists (select 1 from public.project_members m
                  where m.project_id = p.id and m.user_id = auth.uid())
  loop
    return query
      select r.id,
             r.name,
             s.totalclientes,
             s.pertodeganhar,
             s.completos
      from public.fn_get_stats(r.id) as s;
  end loop;
end $$;


ALTER FUNCTION "public"."fn_get_stats_all"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."fn_issuer_from_class"("p_class_id" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE
    AS $$
  SELECT split_part(btrim(p_class_id), '.', 1)
$$;


ALTER FUNCTION "public"."fn_issuer_from_class"("p_class_id" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."fn_link_member_by_email"("p_email" "text", "p_project" "uuid", "p_role" "text" DEFAULT 'staff'::"text") RETURNS TABLE("ok" boolean, "user_id" "uuid")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'auth'
    AS $$
declare
  uid uuid;
  attempts integer := 0;
begin
  -- Tenta encontrar o usuário, com algumas tentativas para lidar com a replicação
  while uid is null and attempts < 5 loop
    select id into uid from auth.users where email = p_email;
    if uid is null then
      attempts := attempts + 1;
      perform pg_sleep(0.1); -- Espera 100ms antes de tentar novamente
    end if;
  end loop;

  if uid is null then
    raise exception 'Falha ao encontrar o usuário % no sistema de autenticação após várias tentativas.', p_email;
  end if;

  -- Garante que o perfil exista e tenha o papel 'establishment'
  insert into public.profiles (id, role)
  values (uid, 'establishment')
  on conflict (id) do update 
  set role = 'establishment'
  where profiles.role is distinct from 'establishment';

  -- Garante o vínculo do membro ao projeto com o papel desejado
  insert into public.project_members (project_id, user_id, role)
  values (p_project, uid, coalesce(nullif(lower(p_role),''),'staff'))
  on conflict (project_id, user_id) do update 
  set role = excluded.role;

  return query select true, uid;
end;
$$;


ALTER FUNCTION "public"."fn_link_member_by_email"("p_email" "text", "p_project" "uuid", "p_role" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."fn_list_customers_with_visits"("p_project_id" "uuid") RETURNS TABLE("id" "uuid", "google_sub" "text", "name" "text", "email" "text", "created_at" timestamp with time zone, "visits" integer)
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT
    c.id,
    c.google_sub,
    c.name,
    c.email,
    c.created_at,
    COALESCE(ls.points, 0)::integer as visits
  FROM public.customers c
  LEFT JOIN public.loyalty_states ls ON c.id = ls.customer_id AND c.project_id = ls.project_id
  WHERE c.project_id = p_project_id
  ORDER BY c.created_at DESC;
$$;


ALTER FUNCTION "public"."fn_list_customers_with_visits"("p_project_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."fn_list_members"("p_project" "uuid") RETURNS TABLE("user_id" "uuid", "email" "text", "role" "text", "created_at" timestamp with time zone)
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  select
    pm.user_id,
    (select u.email from auth.users u where u.id = pm.user_id)::text as email,
    pm.role::text,
    pm.created_at
  from public.project_members pm
  where pm.project_id = p_project
  order by pm.created_at desc;
$$;


ALTER FUNCTION "public"."fn_list_members"("p_project" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."fn_list_visits"("p_project_id" "uuid") RETURNS TABLE("id" "uuid", "customer_google_sub" "text", "customer_email" "text", "visited_at" timestamp with time zone)
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT
    e.id,
    c.google_sub as customer_google_sub,
    c.email as customer_email,
    e.at as visited_at
  FROM public.events e
  JOIN public.customers c ON e.customer_id = c.id
  WHERE e.project_id = p_project_id AND e.type = 'visit'
  ORDER BY e.at DESC;
$$;


ALTER FUNCTION "public"."fn_list_visits"("p_project_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."fn_scanner_visit"("p_project" "uuid", "p_google_sub" "text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
declare
  u uuid := auth.uid();
  v_is_admin boolean;
  v_is_member boolean;
  v_customer_id uuid;
  v_points int;
  v_cycle_start date;
  v_cycle_end date;
  v_completed boolean := false;
  v_now timestamptz := now();
begin
  -- permissão: membro do projeto ou superadmin
  select public.is_superadmin() into v_is_admin;
  select public.is_member_of(p_project) into v_is_member;

  if not v_is_admin and not v_is_member then
    raise exception 'Acesso negado. Você não tem permissão para registrar visitas neste projeto.';
  end if;

  -- upsert do cliente
  insert into public.customers (project_id, google_sub, name, email)
  values (p_project, p_google_sub, null, null)
  on conflict (project_id, google_sub) do nothing;

  select id into v_customer_id
  from public.customers
  where project_id = p_project and google_sub = p_google_sub;

  -- upsert do estado
  insert into public.loyalty_states (project_id, customer_id, points, cycle_start, cycle_end)
  values (p_project, v_customer_id, 0, v_now::date, (v_now::date + interval '30 days')::date)
  on conflict (project_id, customer_id) do nothing;

  -- ciclo/points
  select points, cycle_start, cycle_end
    into v_points, v_cycle_start, v_cycle_end
  from public.loyalty_states
  where project_id = p_project and customer_id = v_customer_id
  for update;

  if v_now::date > v_cycle_end then
    v_points := 0;
    v_cycle_start := v_now::date;
    v_cycle_end := (v_now::date + interval '30 days')::date;
  end if;

  v_points := coalesce(v_points,0) + 1;
  if v_points >= 10 then
    v_completed := true;
  end if;

  update public.loyalty_states
  set points = v_points,
      cycle_start = v_cycle_start,
      cycle_end = v_cycle_end,
      updated_at = v_now
  where project_id = p_project and customer_id = v_customer_id;

  insert into public.events(project_id, customer_id, type, value, at, meta)
  values (p_project, v_customer_id, 'visit', '1', v_now, jsonb_build_object('scanner_id', u));

  if v_completed then
    insert into public.events(project_id, customer_id, type, value, at, meta)
    values (p_project, v_customer_id, 'reward_unlocked', null, v_now, jsonb_build_object('points', v_points));
  end if;

  return jsonb_build_object(
    'points', v_points,
    'cycle_start', v_cycle_start,
    'cycle_end', v_cycle_end,
    'completed', v_completed
  );
end $$;


ALTER FUNCTION "public"."fn_scanner_visit"("p_project" "uuid", "p_google_sub" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."fn_upsert_customer"("p_project" "uuid", "p_google_sub" "text", "p_email" "text" DEFAULT NULL::"text", "p_name" "text" DEFAULT NULL::"text") RETURNS "uuid"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  v_id uuid;
BEGIN
  SELECT id INTO v_id FROM public.customers WHERE project_id = p_project AND google_sub = p_google_sub;
  IF v_id IS NULL THEN
    INSERT INTO public.customers(project_id, google_sub, email, name) VALUES (p_project, p_google_sub, p_email, p_name) RETURNING id INTO v_id;
  ELSE
    UPDATE public.customers SET email = COALESCE(p_email, email), name = COALESCE(p_name, name) WHERE id = v_id;
  END IF;
  RETURN v_id;
END;
$$;


ALTER FUNCTION "public"."fn_upsert_customer"("p_project" "uuid", "p_google_sub" "text", "p_email" "text", "p_name" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."fn_upsert_customer"("p_project_id" "uuid", "p_google_sub" "text", "p_name" "text", "p_email" "text", "p_avatar_url" "text") RETURNS "uuid"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
    v_customer_id uuid;
BEGIN
    INSERT INTO public.customers (project_id, google_sub, name, email, avatar_url)
    VALUES (p_project_id, p_google_sub, p_name, p_email, p_avatar_url)
    ON CONFLICT (project_id, google_sub)
    DO UPDATE SET
        name = COALESCE(EXCLUDED.name, customers.name),
        email = COALESCE(EXCLUDED.email, customers.email),
        avatar_url = COALESCE(EXCLUDED.avatar_url, customers.avatar_url),
        updated_at = NOW()
    RETURNING id INTO v_customer_id;
    
    INSERT INTO public.loyalty_states (customer_id)
    VALUES (v_customer_id)
    ON CONFLICT (customer_id) DO NOTHING;
    
    RETURN v_customer_id;
END;
$$;


ALTER FUNCTION "public"."fn_upsert_customer"("p_project_id" "uuid", "p_google_sub" "text", "p_name" "text", "p_email" "text", "p_avatar_url" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."fn_upsert_customer_v2"("p_project_id" "uuid", "p_google_sub" "text", "p_name" "text", "p_email" "text") RETURNS "uuid"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
    v_customer_id uuid;
BEGIN
    IF p_project_id IS NULL OR p_google_sub IS NULL THEN
        RAISE EXCEPTION 'project_id e google_sub são obrigatórios';
    END IF;

    INSERT INTO public.customers (project_id, google_sub, name, email)
    VALUES (p_project_id, p_google_sub, p_name, p_email)
    ON CONFLICT (project_id, google_sub)
    DO UPDATE SET
        name = EXCLUDED.name,
        email = EXCLUDED.email,
        updated_at = NOW()
    RETURNING id INTO v_customer_id;

    RETURN v_customer_id;
END;
$$;


ALTER FUNCTION "public"."fn_upsert_customer_v2"("p_project_id" "uuid", "p_google_sub" "text", "p_name" "text", "p_email" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_pass_owner"("p_token" "text") RETURNS "uuid"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT user_id FROM public.user_passes WHERE pass_token = p_token LIMIT 1;
$$;


ALTER FUNCTION "public"."get_pass_owner"("p_token" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_wallet_link_and_customer_points"("p_project_id" "uuid", "p_google_sub" "text") RETURNS TABLE("wallet_link_id" "uuid", "google_object_id" "text", "customer_id" "uuid", "points" integer, "cycle_start" "date", "cycle_end" "date", "last_visit_at" timestamp with time zone)
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_customer_id uuid;
  v_wallet_link_id uuid;
  v_google_object_id text;
  v_ls_id uuid;
  v_now timestamptz := now();
  v_first_visit timestamptz;
  v_visits_count int;
BEGIN
  SELECT c.id, wl.id, wl.google_object_id
    INTO v_customer_id, v_wallet_link_id, v_google_object_id
  FROM public.customers c
  LEFT JOIN public.wallet_links wl ON wl.customer_id = c.id AND wl.project_id = p_project_id
  WHERE c.project_id = p_project_id AND c.google_sub = p_google_sub
  LIMIT 1;

  IF v_customer_id IS NULL THEN
    RETURN;
  END IF;

  -- Try to find existing loyalty_state
  SELECT id, points, cycle_start, cycle_end
    INTO v_ls_id, points, cycle_start, cycle_end
  FROM public.loyalty_states
  WHERE project_id = p_project_id AND customer_id = v_customer_id
  LIMIT 1;

  -- Determine last visit
  SELECT max(created_at) INTO last_visit_at FROM public.visits WHERE project_id = p_project_id AND customer_id = v_customer_id;

  IF v_ls_id IS NULL THEN
    -- No state: compute based on visits in last 30 days
    SELECT min(created_at) INTO v_first_visit FROM public.visits WHERE project_id = p_project_id AND customer_id = v_customer_id AND created_at >= v_now - interval '30 days';
    IF v_first_visit IS NULL THEN
      -- No recent visits, create new cycle starting today with 0 points
      INSERT INTO public.loyalty_states(project_id, customer_id, points, cycle_start, cycle_end, updated_at)
      VALUES (p_project_id, v_customer_id, 0, CURRENT_DATE, (CURRENT_DATE + 30), now())
      RETURNING id, points, cycle_start, cycle_end INTO v_ls_id, points, cycle_start, cycle_end;
    ELSE
      -- Count visits since first visit in window
      SELECT count(*) INTO v_visits_count FROM public.visits WHERE project_id = p_project_id AND customer_id = v_customer_id AND created_at >= v_first_visit;
      points := LEAST(v_visits_count, 10);
      INSERT INTO public.loyalty_states(project_id, customer_id, points, cycle_start, cycle_end, updated_at)
      VALUES (p_project_id, v_customer_id, points, v_first_visit::date, (v_first_visit::date + 30), now())
      RETURNING id, points, cycle_start, cycle_end INTO v_ls_id, points, cycle_start, cycle_end;
    END IF;
  ELSE
    -- Existing state: check expiry or 10+ visits/reward
    IF cycle_end IS NOT NULL AND v_now::date >= cycle_end THEN
      -- cycle expired: start new cycle from first recent visit or today
      SELECT min(created_at) INTO v_first_visit FROM public.visits WHERE project_id = p_project_id AND customer_id = v_customer_id AND created_at >= v_now - interval '30 days';
      IF v_first_visit IS NULL THEN
        UPDATE public.loyalty_states SET points = 0, cycle_start = CURRENT_DATE, cycle_end = (CURRENT_DATE + 30), updated_at = now() WHERE id = v_ls_id RETURNING points, cycle_start, cycle_end INTO points, cycle_start, cycle_end;
      ELSE
        SELECT count(*) INTO v_visits_count FROM public.visits WHERE project_id = p_project_id AND customer_id = v_customer_id AND created_at >= v_first_visit;
        points := LEAST(v_visits_count, 10);
        UPDATE public.loyalty_states SET points = points, cycle_start = v_first_visit::date, cycle_end = (v_first_visit::date + 30), updated_at = now() WHERE id = v_ls_id RETURNING points, cycle_start, cycle_end INTO points, cycle_start, cycle_end;
      END IF;
    ELSE
      -- cycle still valid: count visits since cycle_start
      SELECT count(*) INTO v_visits_count FROM public.visits WHERE project_id = p_project_id AND customer_id = v_customer_id AND created_at >= cycle_start;
      IF v_visits_count >= 10 THEN
        -- Redeem: reset points and set new cycle_start to now
        UPDATE public.loyalty_states SET points = 0, cycle_start = CURRENT_DATE, cycle_end = (CURRENT_DATE + 30), updated_at = now() WHERE id = v_ls_id RETURNING points, cycle_start, cycle_end INTO points, cycle_start, cycle_end;
        -- record reward_unlocked event
        INSERT INTO public.events(project_id, customer_id, type, value, meta, at)
        VALUES (p_project_id, v_customer_id, 'reward_unlocked', NULL, jsonb_build_object('reason','auto_redeem','visits', v_visits_count), now());
      ELSE
        points := v_visits_count;
        UPDATE public.loyalty_states SET points = points, updated_at = now() WHERE id = v_ls_id RETURNING points, cycle_start, cycle_end INTO points, cycle_start, cycle_end;
      END IF;
    END IF;
  END IF;

  wallet_link_id := v_wallet_link_id;
  google_object_id := v_google_object_id;
  customer_id := v_customer_id;

  RETURN NEXT;
END;
$$;


ALTER FUNCTION "public"."get_wallet_link_and_customer_points"("p_project_id" "uuid", "p_google_sub" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."handle_new_auth_user"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
begin
  insert into public.profiles (id, role)
  values (new.id, 'restaurant')
  on conflict (id) do nothing;
  return new;
end;
$$;


ALTER FUNCTION "public"."handle_new_auth_user"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."handle_new_user"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  INSERT INTO public.profiles (id, email, name, avatar_url, role)
  VALUES (new.id, new.raw_user_meta_data->>'email', new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'avatar_url', 'customer')
  ON CONFLICT (id) DO NOTHING;
  return new;
END;
$$;


ALTER FUNCTION "public"."handle_new_user"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."is_member_of"("p_project" "uuid") RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  SELECT EXISTS(
    SELECT 1 FROM public.project_members pm
    WHERE pm.project_id = p_project AND pm.user_id = auth.uid()
  );
$$;


ALTER FUNCTION "public"."is_member_of"("p_project" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."is_member_of_org"("p_user_id" "uuid", "p_org_id" "uuid") RETURNS boolean
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.org_members
    WHERE org_id = p_org_id AND user_id = p_user_id
  );
$$;


ALTER FUNCTION "public"."is_member_of_org"("p_user_id" "uuid", "p_org_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."is_member_of_project"("p_project" "uuid") RETURNS boolean
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  select exists (
    select 1 from public.project_members pm
    where pm.project_id = p_project and pm.user_id = auth.uid()
  );
$$;


ALTER FUNCTION "public"."is_member_of_project"("p_project" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."is_member_of_project"("p_user" "uuid", "p_project" "uuid") RETURNS boolean
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT EXISTS (SELECT 1 FROM public.project_members pm WHERE pm.user_id = p_user AND pm.project_id = p_project);
$$;


ALTER FUNCTION "public"."is_member_of_project"("p_user" "uuid", "p_project" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."is_org_admin"("p_user_id" "uuid", "p_org_id" "uuid") RETURNS boolean
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.org_members
    WHERE org_id = p_org_id AND user_id = p_user_id AND role = 'admin'
  );
$$;


ALTER FUNCTION "public"."is_org_admin"("p_user_id" "uuid", "p_org_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."is_pass_belongs_to_current_user_by_token"("token_text" "text") RETURNS boolean
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT EXISTS (
    SELECT 1
    FROM user_passes up
    WHERE up.pass_token = token_text
      AND up.user_id = (SELECT auth.uid())
  );
$$;


ALTER FUNCTION "public"."is_pass_belongs_to_current_user_by_token"("token_text" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."is_superadmin"() RETURNS boolean
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  select exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'superadmin');
$$;


ALTER FUNCTION "public"."is_superadmin"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."log_wallet_config_change"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
    BEGIN
        INSERT INTO public.wallet_configs_history (wallet_config_id, project_id, pass_template, reason)
        VALUES (NEW.id, NEW.project_id, NEW.pass_template, 'config_update');
        RETURN NEW;
    END;
    $$;


ALTER FUNCTION "public"."log_wallet_config_change"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."prevent_multiple_sessions"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  BEGIN
    DELETE FROM auth.sessions
    WHERE user_id = NEW.user_id
      AND id <> NEW.id;
  EXCEPTION WHEN OTHERS THEN
    RETURN NEW;
  END;

  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."prevent_multiple_sessions"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."read_secret"("secret_name" "text") RETURNS "text"
    LANGUAGE "sql" SECURITY DEFINER
    AS $$
  SELECT value::text
  FROM secrets
  WHERE name = secret_name
  LIMIT 1;
$$;


ALTER FUNCTION "public"."read_secret"("secret_name" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."set_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
  new.updated_at = now();
  return new;
end $$;


ALTER FUNCTION "public"."set_updated_at"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_wallet_link_google_object_id"("p_wallet_link_id" "uuid", "p_google_object_id" "text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  UPDATE public.wallet_links
  SET google_object_id = p_google_object_id,
      updated_at = now()
  WHERE id = p_wallet_link_id;

  RETURN jsonb_build_object('ok', true, 'wallet_link_id', p_wallet_link_id, 'google_object_id', p_google_object_id);
EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', SQLERRM);
END;
$$;


ALTER FUNCTION "public"."update_wallet_link_google_object_id"("p_wallet_link_id" "uuid", "p_google_object_id" "text") OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";


CREATE TABLE IF NOT EXISTS "public"."clients" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "google_sub" "text" NOT NULL,
    "name" "text",
    "email" "text",
    "profile_pic" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."clients" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."customers" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "project_id" "uuid" DEFAULT '0f9c8c77-3eaf-4dc7-b4b7-4bdbd6536b32'::"uuid" NOT NULL,
    "google_sub" "text" NOT NULL,
    "name" "text",
    "email" "text",
    "job_tag" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "avatar_url" "text",
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."customers" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."events" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "project_id" "uuid" NOT NULL,
    "customer_id" "uuid",
    "type" "text" NOT NULL,
    "value" "text",
    "meta" "jsonb" DEFAULT '{}'::"jsonb",
    "at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "events_type_check" CHECK (("type" = ANY (ARRAY['signup'::"text", 'visit'::"text", 'reward_unlocked'::"text", 'wallet_linked'::"text", 'note'::"text"])))
);


ALTER TABLE "public"."events" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."function_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "function_name" "text" NOT NULL,
    "level" "text" NOT NULL,
    "meta" "jsonb" DEFAULT '{}'::"jsonb",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."function_logs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."locations" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "project_id" "uuid" NOT NULL,
    "label" "text",
    "lat" numeric(9,6),
    "lng" numeric(9,6),
    "radius" integer DEFAULT 200 NOT NULL,
    CONSTRAINT "locations_lat_lng_range_chk" CHECK (((("lat" IS NULL) OR (("lat" >= ('-90'::integer)::numeric) AND ("lat" <= (90)::numeric))) AND (("lng" IS NULL) OR (("lng" >= ('-180'::integer)::numeric) AND ("lng" <= (180)::numeric)))))
);


ALTER TABLE "public"."locations" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."loyalty_states" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "project_id" "uuid" NOT NULL,
    "customer_id" "uuid" NOT NULL,
    "points" integer DEFAULT 0 NOT NULL,
    "cycle_start" "date" DEFAULT CURRENT_DATE NOT NULL,
    "cycle_end" "date" DEFAULT (CURRENT_DATE + 30) NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."loyalty_states" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."notifications" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "project_id" "uuid" NOT NULL,
    "title" "text" NOT NULL,
    "message" "text" NOT NULL,
    "channels" "jsonb" NOT NULL,
    "trigger_type" "text" NOT NULL,
    "trigger_config" "jsonb",
    "status" "text" DEFAULT 'scheduled'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "scheduled_for" timestamp with time zone,
    "sent_at" timestamp with time zone
);


ALTER TABLE "public"."notifications" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."org_members" (
    "org_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "role" "text" DEFAULT 'member'::"text" NOT NULL
);


ALTER TABLE "public"."org_members" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."orgs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "owner_id" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."orgs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."passes" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "project_id" "text" NOT NULL,
    "template_id" "text",
    "serial_number" "text" NOT NULL,
    "email" "text",
    "status" "text" DEFAULT 'issued'::"text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "project_slug" "text",
    "type" "text",
    "title" "text",
    "description" "text",
    "google_jwt" "text",
    "apple_url" "text",
    "qr_url" "text",
    "apple_pass_base64" "text",
    "design" "jsonb",
    "fields" "jsonb",
    "universal_url" "text",
    CONSTRAINT "passes_type_check" CHECK (("type" = ANY (ARRAY['fidelidade'::"text", 'cupom'::"text", 'evento'::"text", 'outro'::"text"])))
);


ALTER TABLE "public"."passes" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."passkit_events" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "event_type" "text" NOT NULL,
    "pass_id" "text",
    "serial_number" "text",
    "payload" "jsonb",
    "headers" "jsonb",
    "is_valid_signature" boolean,
    "processed_at" timestamp with time zone DEFAULT "now"(),
    "error_message" "text"
);


ALTER TABLE "public"."passkit_events" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."profiles" (
    "id" "uuid" NOT NULL,
    "role" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "email" "text",
    CONSTRAINT "profiles_role_check" CHECK (("role" = ANY (ARRAY['superadmin'::"text", 'establishment'::"text", 'customer'::"text"])))
);


ALTER TABLE "public"."profiles" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."project_members" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "project_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "role" "text" DEFAULT 'owner'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "project_members_role_check" CHECK (("role" = ANY (ARRAY['owner'::"text", 'staff'::"text"])))
);


ALTER TABLE "public"."project_members" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."project_wallets" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "project_id" "uuid" NOT NULL,
    "wallet_address" "text" NOT NULL,
    "chain" "text" NOT NULL,
    "label" "text",
    "google_sub" "text",
    "google_email" "text",
    "google_name" "text",
    "google_picture" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."project_wallets" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."projects" (
    "id" "text" NOT NULL,
    "name" "text",
    "template_id" "text",
    "auth_mode" "text" DEFAULT 'google_only'::"text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "description" "text",
    "logo_url" "text",
    "extra_form_schema" "jsonb" DEFAULT '[]'::"jsonb",
    "pass_type" "text",
    "wallet_design" "jsonb",
    "field_mapping" "jsonb",
    "apple_template_id" "text",
    "google_template_id" "text",
    "wallet_template_id" "uuid",
    "slug" "text",
    CONSTRAINT "projects_auth_mode_check" CHECK (("auth_mode" = ANY (ARRAY['google_only'::"text", 'google_plus_form'::"text", 'form_only'::"text"])))
);


ALTER TABLE "public"."projects" OWNER TO "postgres";


COMMENT ON COLUMN "public"."projects"."auth_mode" IS 'Define o fluxo de cadastro: google_only, google_plus_form, form_only';



COMMENT ON COLUMN "public"."projects"."extra_form_schema" IS 'Define os campos customizados para o formulário de cadastro adicional.';



CREATE TABLE IF NOT EXISTS "public"."secrets" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "value" "jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."secrets" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_passes" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "pass_token" "text" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "pass_type" "text" DEFAULT 'google'::"text" NOT NULL,
    "metadata" "jsonb" DEFAULT '{}'::"jsonb",
    "issued_at" timestamp with time zone DEFAULT "now"(),
    "expires_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."user_passes" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_wallets" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "address" "text" NOT NULL,
    "chain" "text" NOT NULL,
    "label" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."user_wallets" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."v_passes" AS
 SELECT "id",
    "project_id",
    "project_slug",
    "type",
    "title",
    "description",
    "google_jwt",
    "apple_url",
    "qr_url",
    "universal_url",
    "status",
    "created_at"
   FROM "public"."passes" "p";


ALTER VIEW "public"."v_passes" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."visits" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "project_id" "uuid" NOT NULL,
    "customer_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "pass_token" "text"
);


ALTER TABLE "public"."visits" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."wallet_configs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "project_id" "text" NOT NULL,
    "apple_pass_type_id" "text",
    "apple_team_id" "text",
    "apple_key_id" "text",
    "google_issuer_id" "text",
    "google_class_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "card_title" "text",
    "reward_description" "text",
    "terms_and_conditions" "text",
    "background_color" character varying(7) DEFAULT '#7852ee'::character varying,
    "foreground_color" character varying(7) DEFAULT '#ffffff'::character varying,
    "label_color" character varying(7) DEFAULT '#ffffff'::character varying,
    "background_image_url" "text",
    "pass_template" "jsonb",
    "google_service_account_json" "text",
    "apple_private_key_p8" "text",
    "apple_private_key_password" "text",
    "google_service_account_path" "text",
    "apple_private_key_path" "text",
    "design" "jsonb",
    "default_google_class_id" "text",
    CONSTRAINT "wallet_configs_google_class_format_chk" CHECK ((("google_class_id" IS NULL) OR ((POSITION(('.'::"text") IN ("btrim"("google_class_id"))) > 0) AND ("split_part"("btrim"("google_class_id"), '.'::"text", 1) <> ''::"text") AND ("split_part"("btrim"("google_class_id"), '.'::"text", 2) <> ''::"text"))))
);


ALTER TABLE "public"."wallet_configs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."wallet_configs_history" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "wallet_config_id" "uuid",
    "project_id" "uuid" NOT NULL,
    "pass_template" "jsonb",
    "reason" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."wallet_configs_history" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."wallet_links" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "project_id" "uuid" NOT NULL,
    "customer_id" "uuid" NOT NULL,
    "google_object_id" "text",
    "apple_pass_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."wallet_links" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."wallet_templates" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "project_id" "text",
    "name" "text" DEFAULT 'Default Wallet Template'::"text" NOT NULL,
    "defaults" "jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."wallet_templates" OWNER TO "postgres";


ALTER TABLE ONLY "public"."clients"
    ADD CONSTRAINT "clients_google_sub_key" UNIQUE ("google_sub");



ALTER TABLE ONLY "public"."clients"
    ADD CONSTRAINT "clients_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."customers"
    ADD CONSTRAINT "customers_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."events"
    ADD CONSTRAINT "events_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."function_logs"
    ADD CONSTRAINT "function_logs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."locations"
    ADD CONSTRAINT "locations_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."loyalty_states"
    ADD CONSTRAINT "loyalty_states_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."loyalty_states"
    ADD CONSTRAINT "loyalty_states_project_id_customer_id_key" UNIQUE ("project_id", "customer_id");



ALTER TABLE ONLY "public"."notifications"
    ADD CONSTRAINT "notifications_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."org_members"
    ADD CONSTRAINT "org_members_pkey" PRIMARY KEY ("org_id", "user_id");



ALTER TABLE ONLY "public"."orgs"
    ADD CONSTRAINT "orgs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."passes"
    ADD CONSTRAINT "passes_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."passes"
    ADD CONSTRAINT "passes_project_slug_key" UNIQUE ("project_slug");



ALTER TABLE ONLY "public"."passes"
    ADD CONSTRAINT "passes_serial_number_key" UNIQUE ("serial_number");



ALTER TABLE ONLY "public"."passkit_events"
    ADD CONSTRAINT "passkit_events_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."project_members"
    ADD CONSTRAINT "project_members_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."project_members"
    ADD CONSTRAINT "project_members_project_id_user_id_key" UNIQUE ("project_id", "user_id");



ALTER TABLE ONLY "public"."project_wallets"
    ADD CONSTRAINT "project_wallets_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."projects"
    ADD CONSTRAINT "projects_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."projects"
    ADD CONSTRAINT "projects_slug_key" UNIQUE ("slug");



ALTER TABLE ONLY "public"."secrets"
    ADD CONSTRAINT "secrets_name_key" UNIQUE ("name");



ALTER TABLE ONLY "public"."secrets"
    ADD CONSTRAINT "secrets_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."user_passes"
    ADD CONSTRAINT "user_passes_pass_token_key" UNIQUE ("pass_token");



ALTER TABLE ONLY "public"."user_passes"
    ADD CONSTRAINT "user_passes_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."user_wallets"
    ADD CONSTRAINT "user_wallets_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."user_wallets"
    ADD CONSTRAINT "user_wallets_user_id_address_chain_key" UNIQUE ("user_id", "address", "chain");



ALTER TABLE ONLY "public"."visits"
    ADD CONSTRAINT "visits_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."wallet_configs_history"
    ADD CONSTRAINT "wallet_configs_history_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."wallet_configs"
    ADD CONSTRAINT "wallet_configs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."wallet_configs"
    ADD CONSTRAINT "wallet_configs_project_id_key" UNIQUE ("project_id");



ALTER TABLE ONLY "public"."wallet_links"
    ADD CONSTRAINT "wallet_links_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."wallet_templates"
    ADD CONSTRAINT "wallet_templates_pkey" PRIMARY KEY ("id");



CREATE UNIQUE INDEX "customers_project_id_google_sub_idx" ON "public"."customers" USING "btree" ("project_id", "google_sub");



CREATE INDEX "events_project_id_at_idx" ON "public"."events" USING "btree" ("project_id", "at" DESC);



CREATE INDEX "idx_customers_project_google_sub" ON "public"."customers" USING "btree" ("project_id", "google_sub");



CREATE INDEX "idx_loyalty_states_project_customer" ON "public"."loyalty_states" USING "btree" ("project_id", "customer_id");



CREATE INDEX "idx_project_members_user_id" ON "public"."project_members" USING "btree" ("user_id");



CREATE INDEX "idx_project_wallets_google_sub" ON "public"."project_wallets" USING "btree" ("google_sub");



CREATE INDEX "idx_project_wallets_project_id" ON "public"."project_wallets" USING "btree" ("project_id");



CREATE INDEX "idx_project_wallets_wallet_address" ON "public"."project_wallets" USING "btree" ("wallet_address");



CREATE INDEX "idx_visits_pass_token" ON "public"."visits" USING "btree" ("pass_token");



CREATE INDEX "idx_visits_project_created_at" ON "public"."visits" USING "btree" ("project_id", "created_at");



CREATE UNIQUE INDEX "project_members_project_user_key" ON "public"."project_members" USING "btree" ("project_id", "user_id");



CREATE UNIQUE INDEX "uq_customers_project_sub" ON "public"."customers" USING "btree" ("project_id", "google_sub");



CREATE UNIQUE INDEX "uq_project_members_project_user" ON "public"."project_members" USING "btree" ("project_id", "user_id");



CREATE UNIQUE INDEX "uq_wallet_links_apple_pass" ON "public"."wallet_links" USING "btree" ("apple_pass_id") WHERE ("apple_pass_id" IS NOT NULL);



CREATE UNIQUE INDEX "uq_wallet_links_google_object" ON "public"."wallet_links" USING "btree" ("google_object_id") WHERE ("google_object_id" IS NOT NULL);



CREATE UNIQUE INDEX "uq_wallet_links_project_customer" ON "public"."wallet_links" USING "btree" ("project_id", "customer_id");



CREATE UNIQUE INDEX "wallet_templates_project_id_key" ON "public"."wallet_templates" USING "btree" ("project_id");



CREATE UNIQUE INDEX "wallet_templates_project_idx" ON "public"."wallet_templates" USING "btree" ("project_id") WHERE ("project_id" IS NOT NULL);



CREATE OR REPLACE TRIGGER "trg_loyalty_states_set_updated_at" BEFORE UPDATE ON "public"."loyalty_states" FOR EACH ROW EXECUTE FUNCTION "public"."set_updated_at"();



CREATE OR REPLACE TRIGGER "wallet_config_update_trigger" AFTER UPDATE ON "public"."wallet_configs" FOR EACH ROW WHEN (("old"."pass_template" IS DISTINCT FROM "new"."pass_template")) EXECUTE FUNCTION "public"."log_wallet_config_change"();



ALTER TABLE ONLY "public"."events"
    ADD CONSTRAINT "events_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."loyalty_states"
    ADD CONSTRAINT "loyalty_states_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."org_members"
    ADD CONSTRAINT "org_members_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."orgs"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."org_members"
    ADD CONSTRAINT "org_members_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."orgs"
    ADD CONSTRAINT "orgs_owner_id_fkey" FOREIGN KEY ("owner_id") REFERENCES "auth"."users"("id");



ALTER TABLE ONLY "public"."passes"
    ADD CONSTRAINT "passes_project_id_fkey" FOREIGN KEY ("project_id") REFERENCES "public"."projects"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."passes"
    ADD CONSTRAINT "passes_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id");



ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_id_fkey" FOREIGN KEY ("id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."project_members"
    ADD CONSTRAINT "project_members_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."user_wallets"
    ADD CONSTRAINT "user_wallets_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."wallet_configs_history"
    ADD CONSTRAINT "wallet_configs_history_wallet_config_id_fkey" FOREIGN KEY ("wallet_config_id") REFERENCES "public"."wallet_configs"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."wallet_links"
    ADD CONSTRAINT "wallet_links_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE CASCADE;



CREATE POLICY "Allow admins" ON "public"."wallet_configs" USING ("public"."is_superadmin"());



CREATE POLICY "Allow anonymous insert on customers" ON "public"."customers" FOR INSERT TO "anon" WITH CHECK (true);



CREATE POLICY "Allow anonymous read on customers" ON "public"."customers" FOR SELECT TO "anon" USING (true);



CREATE POLICY "Allow authenticated read access" ON "public"."projects" FOR SELECT TO "authenticated" USING (true);



CREATE POLICY "Allow inserts for service role" ON "public"."customers" FOR INSERT TO "service_role" WITH CHECK (true);



CREATE POLICY "Allow selects for service role" ON "public"."customers" FOR SELECT TO "service_role" USING (true);



CREATE POLICY "Allow service role to delete projects" ON "public"."projects" FOR DELETE TO "service_role" USING (true);



CREATE POLICY "Allow service role to update projects" ON "public"."projects" FOR UPDATE TO "service_role" USING (true) WITH CHECK (true);



CREATE POLICY "Allow service_role access" ON "public"."passkit_events" USING (true);



CREATE POLICY "Allow superadmins to delete projects" ON "public"."projects" FOR DELETE TO "authenticated" USING ("public"."is_superadmin"());



CREATE POLICY "Allow superadmins to insert projects" ON "public"."projects" FOR INSERT TO "authenticated", "service_role" WITH CHECK ("public"."is_superadmin"());



CREATE POLICY "Allow superadmins to update projects" ON "public"."projects" FOR UPDATE TO "authenticated" USING ("public"."is_superadmin"()) WITH CHECK ("public"."is_superadmin"());



CREATE POLICY "Authenticated users can create orgs." ON "public"."orgs" FOR INSERT WITH CHECK (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Customers can view their own loyalty state." ON "public"."loyalty_states" FOR SELECT USING (("customer_id" IN ( SELECT "customers"."id"
   FROM "public"."customers"
  WHERE ("customers"."google_sub" = ("auth"."jwt"() ->> 'sub'::"text")))));



CREATE POLICY "Deny all by default" ON "public"."passes" USING (false);



CREATE POLICY "Enable read access for project members" ON "public"."wallet_configs_history" FOR SELECT USING (("public"."is_member_of_project"("project_id") OR "public"."is_superadmin"()));



CREATE POLICY "Full access for service_role" ON "public"."customers" TO "service_role" USING (true) WITH CHECK (true);



CREATE POLICY "Negar tudo por padrão" ON "public"."passes" USING (false) WITH CHECK (false);



CREATE POLICY "Org admins can manage members" ON "public"."org_members" USING (("public"."is_superadmin"() OR "public"."is_org_admin"("auth"."uid"(), "org_id")));



CREATE POLICY "Org members can view other members" ON "public"."org_members" FOR SELECT USING (("public"."is_superadmin"() OR "public"."is_member_of_org"("auth"."uid"(), "org_id")));



CREATE POLICY "Org owners can update their org." ON "public"."orgs" FOR UPDATE USING (("auth"."uid"() = "owner_id"));



CREATE POLICY "Owners and members can view their org." ON "public"."orgs" FOR SELECT USING (("id" IN ( SELECT "org_members"."org_id"
   FROM "public"."org_members"
  WHERE ("org_members"."user_id" = "auth"."uid"()))));



CREATE POLICY "Public read access to wallet configs" ON "public"."wallet_configs" FOR SELECT USING (true);



CREATE POLICY "Users can delete their own wallets" ON "public"."user_wallets" FOR DELETE USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can insert their own wallets" ON "public"."user_wallets" FOR INSERT WITH CHECK (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can update their own profile." ON "public"."profiles" FOR UPDATE USING (("auth"."uid"() = "id")) WITH CHECK (("auth"."uid"() = "id"));



CREATE POLICY "Users can view their own profile." ON "public"."profiles" FOR SELECT USING (("auth"."uid"() = "id"));



CREATE POLICY "Users can view their own wallets" ON "public"."user_wallets" FOR SELECT USING (("auth"."uid"() = "user_id"));



CREATE POLICY "anon read wallet_configs" ON "public"."wallet_configs" FOR SELECT USING (true);



CREATE POLICY "apenas logado pode criar/atualizar templates" ON "public"."wallet_templates" TO "authenticated" USING (true) WITH CHECK (true);



CREATE POLICY "clientes_insert" ON "public"."customers" FOR INSERT WITH CHECK (true);



CREATE POLICY "clientes_select" ON "public"."customers" FOR SELECT USING (("google_sub" = ("auth"."jwt"() ->> 'sub'::"text")));



CREATE POLICY "clientes_update" ON "public"."customers" FOR UPDATE USING (true);



CREATE POLICY "cust_del" ON "public"."customers" FOR DELETE TO "authenticated" USING (("public"."is_member_of_project"("project_id") OR "public"."is_superadmin"()));



CREATE POLICY "cust_ins" ON "public"."customers" FOR INSERT TO "authenticated" WITH CHECK (("public"."is_member_of_project"("project_id") OR "public"."is_superadmin"()));



CREATE POLICY "cust_read" ON "public"."customers" FOR SELECT TO "authenticated" USING (("public"."is_member_of_project"("project_id") OR "public"."is_superadmin"()));



CREATE POLICY "cust_upd" ON "public"."customers" FOR UPDATE TO "authenticated" USING (("public"."is_member_of_project"("project_id") OR "public"."is_superadmin"())) WITH CHECK (("public"."is_member_of_project"("project_id") OR "public"."is_superadmin"()));



ALTER TABLE "public"."customers" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "customers member read" ON "public"."customers" FOR SELECT USING (("public"."is_superadmin"() OR "public"."is_member_of"("project_id")));



CREATE POLICY "customers_insert_member" ON "public"."customers" FOR INSERT WITH CHECK ("public"."is_member_of_project"(( SELECT "auth"."uid"() AS "uid"), "project_id"));



CREATE POLICY "customers_rw" ON "public"."customers" TO "authenticated" USING (("public"."is_superadmin"() OR (EXISTS ( SELECT 1
   FROM "public"."project_members" "m"
  WHERE (("m"."project_id" = "customers"."project_id") AND ("m"."user_id" = "auth"."uid"())))))) WITH CHECK (("public"."is_superadmin"() OR (EXISTS ( SELECT 1
   FROM "public"."project_members" "m"
  WHERE (("m"."project_id" = "customers"."project_id") AND ("m"."user_id" = "auth"."uid"()))))));



CREATE POLICY "customers_select_member" ON "public"."customers" FOR SELECT USING ("public"."is_member_of_project"(( SELECT "auth"."uid"() AS "uid"), "project_id"));



CREATE POLICY "customers_update_member" ON "public"."customers" FOR UPDATE USING ("public"."is_member_of_project"(( SELECT "auth"."uid"() AS "uid"), "project_id")) WITH CHECK ("public"."is_member_of_project"(( SELECT "auth"."uid"() AS "uid"), "project_id"));



ALTER TABLE "public"."events" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "events member read" ON "public"."events" FOR SELECT USING (("public"."is_superadmin"() OR "public"."is_member_of"("project_id")));



CREATE POLICY "events_ins" ON "public"."events" FOR INSERT TO "authenticated" WITH CHECK (("public"."is_member_of_project"("project_id") OR "public"."is_superadmin"()));



CREATE POLICY "events_read" ON "public"."events" FOR SELECT TO "authenticated" USING (("public"."is_member_of_project"("project_id") OR "public"."is_superadmin"()));



CREATE POLICY "events_rw" ON "public"."events" TO "authenticated" USING (("public"."is_superadmin"() OR (EXISTS ( SELECT 1
   FROM "public"."project_members" "m"
  WHERE (("m"."project_id" = "events"."project_id") AND ("m"."user_id" = "auth"."uid"())))))) WITH CHECK (("public"."is_superadmin"() OR (EXISTS ( SELECT 1
   FROM "public"."project_members" "m"
  WHERE (("m"."project_id" = "events"."project_id") AND ("m"."user_id" = "auth"."uid"()))))));



CREATE POLICY "loc_del" ON "public"."locations" FOR DELETE TO "authenticated" USING (("public"."is_member_of_project"("project_id") OR "public"."is_superadmin"()));



CREATE POLICY "loc_delete" ON "public"."locations" FOR DELETE TO "authenticated" USING ("public"."is_member_of_project"("project_id"));



CREATE POLICY "loc_ins" ON "public"."locations" FOR INSERT TO "authenticated" WITH CHECK (("public"."is_member_of_project"("project_id") OR "public"."is_superadmin"()));



CREATE POLICY "loc_insert" ON "public"."locations" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_member_of_project"("project_id"));



CREATE POLICY "loc_read" ON "public"."locations" FOR SELECT TO "authenticated" USING (("public"."is_member_of_project"("project_id") OR "public"."is_superadmin"()));



CREATE POLICY "loc_upd" ON "public"."locations" FOR UPDATE TO "authenticated" USING (("public"."is_member_of_project"("project_id") OR "public"."is_superadmin"())) WITH CHECK (("public"."is_member_of_project"("project_id") OR "public"."is_superadmin"()));



CREATE POLICY "loc_update" ON "public"."locations" FOR UPDATE TO "authenticated" USING ("public"."is_member_of_project"("project_id")) WITH CHECK ("public"."is_member_of_project"("project_id"));



ALTER TABLE "public"."locations" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "locations_delete" ON "public"."locations" FOR DELETE TO "authenticated" USING (("public"."is_superadmin"() OR (EXISTS ( SELECT 1
   FROM "public"."project_members" "pm"
  WHERE (("pm"."project_id" = "locations"."project_id") AND ("pm"."user_id" = "auth"."uid"()) AND ("pm"."role" = 'owner'::"text"))))));



CREATE POLICY "locations_insert" ON "public"."locations" FOR INSERT TO "authenticated" WITH CHECK (("public"."is_superadmin"() OR (EXISTS ( SELECT 1
   FROM "public"."project_members" "pm"
  WHERE (("pm"."project_id" = "locations"."project_id") AND ("pm"."user_id" = "auth"."uid"()) AND ("pm"."role" = 'owner'::"text"))))));



CREATE POLICY "locations_select" ON "public"."locations" FOR SELECT TO "authenticated" USING (("public"."is_superadmin"() OR (EXISTS ( SELECT 1
   FROM "public"."project_members" "pm"
  WHERE (("pm"."project_id" = "locations"."project_id") AND ("pm"."user_id" = "auth"."uid"()))))));



CREATE POLICY "locations_update" ON "public"."locations" FOR UPDATE TO "authenticated" USING (true) WITH CHECK (("public"."is_superadmin"() OR (EXISTS ( SELECT 1
   FROM "public"."project_members" "pm"
  WHERE (("pm"."project_id" = "locations"."project_id") AND ("pm"."user_id" = "auth"."uid"()) AND ("pm"."role" = 'owner'::"text"))))));



CREATE POLICY "loyalty member read" ON "public"."loyalty_states" FOR SELECT USING (("public"."is_superadmin"() OR "public"."is_member_of"("project_id")));



ALTER TABLE "public"."loyalty_states" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "loyalty_states_member_select" ON "public"."loyalty_states" FOR SELECT USING ("public"."is_member_of_project"(( SELECT "auth"."uid"() AS "uid"), "project_id"));



CREATE POLICY "loyalty_states_member_update" ON "public"."loyalty_states" FOR UPDATE USING ("public"."is_member_of_project"(( SELECT "auth"."uid"() AS "uid"), "project_id")) WITH CHECK ("public"."is_member_of_project"(( SELECT "auth"."uid"() AS "uid"), "project_id"));



CREATE POLICY "loyalty_states_select" ON "public"."loyalty_states" FOR SELECT USING (("customer_id" IN ( SELECT "customers"."id"
   FROM "public"."customers"
  WHERE ("customers"."google_sub" = ("auth"."jwt"() ->> 'sub'::"text")))));



CREATE POLICY "ls_rw" ON "public"."loyalty_states" TO "authenticated" USING (("public"."is_superadmin"() OR (EXISTS ( SELECT 1
   FROM "public"."project_members" "m"
  WHERE (("m"."project_id" = "loyalty_states"."project_id") AND ("m"."user_id" = "auth"."uid"())))))) WITH CHECK (("public"."is_superadmin"() OR (EXISTS ( SELECT 1
   FROM "public"."project_members" "m"
  WHERE (("m"."project_id" = "loyalty_states"."project_id") AND ("m"."user_id" = "auth"."uid"()))))));



ALTER TABLE "public"."notifications" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "notifications_member_access" ON "public"."notifications" USING (("public"."is_member_of_project"("project_id") OR "public"."is_superadmin"())) WITH CHECK (("public"."is_member_of_project"("project_id") OR "public"."is_superadmin"()));



ALTER TABLE "public"."org_members" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."orgs" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."passes" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."passkit_events" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "pm member read" ON "public"."project_members" FOR SELECT USING (("public"."is_superadmin"() OR ("user_id" = "auth"."uid"())));



CREATE POLICY "pm superadmin del" ON "public"."project_members" FOR DELETE USING ("public"."is_superadmin"());



CREATE POLICY "pm superadmin ins" ON "public"."project_members" FOR INSERT WITH CHECK ("public"."is_superadmin"());



CREATE POLICY "pm superadmin upd" ON "public"."project_members" FOR UPDATE USING ("public"."is_superadmin"());



CREATE POLICY "pm_cud" ON "public"."project_members" TO "authenticated" USING ("public"."is_superadmin"()) WITH CHECK ("public"."is_superadmin"());



CREATE POLICY "pm_del" ON "public"."project_members" FOR DELETE TO "authenticated" USING (("public"."is_superadmin"() OR "public"."is_member_of_project"("project_id")));



CREATE POLICY "pm_ins" ON "public"."project_members" FOR INSERT TO "authenticated" WITH CHECK (("public"."is_superadmin"() OR "public"."is_member_of_project"("project_id")));



CREATE POLICY "pm_read" ON "public"."project_members" FOR SELECT TO "authenticated" USING (("public"."is_superadmin"() OR "public"."is_member_of_project"("project_id")));



CREATE POLICY "pm_select" ON "public"."project_members" FOR SELECT TO "authenticated" USING (("public"."is_superadmin"() OR ("user_id" = "auth"."uid"())));



CREATE POLICY "pm_upd" ON "public"."project_members" FOR UPDATE TO "authenticated" USING (("public"."is_superadmin"() OR "public"."is_member_of_project"("project_id"))) WITH CHECK (("public"."is_superadmin"() OR "public"."is_member_of_project"("project_id")));



ALTER TABLE "public"."profiles" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "profiles_insert_auth" ON "public"."profiles" FOR INSERT TO "authenticated" WITH CHECK (true);



CREATE POLICY "profiles_self_update" ON "public"."profiles" FOR UPDATE USING (("id" = "auth"."uid"()));



CREATE POLICY "profiles_self_view" ON "public"."profiles" FOR SELECT TO "authenticated" USING (("auth"."uid"() = "id"));



ALTER TABLE "public"."project_members" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."projects" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "qualquer um pode ler templates" ON "public"."wallet_templates" FOR SELECT TO "authenticated", "anon" USING (true);



ALTER TABLE "public"."user_passes" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "user_passes_owner_delete" ON "public"."user_passes" FOR DELETE TO "authenticated" USING ((( SELECT "auth"."uid"() AS "uid") = "user_id"));



CREATE POLICY "user_passes_owner_insert" ON "public"."user_passes" FOR INSERT TO "authenticated" WITH CHECK ((( SELECT "auth"."uid"() AS "uid") = "user_id"));



CREATE POLICY "user_passes_owner_select" ON "public"."user_passes" FOR SELECT TO "authenticated" USING ((( SELECT "auth"."uid"() AS "uid") = "user_id"));



CREATE POLICY "user_passes_owner_update" ON "public"."user_passes" FOR UPDATE TO "authenticated" USING ((( SELECT "auth"."uid"() AS "uid") = "user_id")) WITH CHECK ((( SELECT "auth"."uid"() AS "uid") = "user_id"));



ALTER TABLE "public"."user_wallets" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."visits" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "visits_insert_member" ON "public"."visits" FOR INSERT WITH CHECK ("public"."is_member_of_project"(( SELECT "auth"."uid"() AS "uid"), "project_id"));



CREATE POLICY "visits_insert_service" ON "public"."visits" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_pass_belongs_to_current_user_by_token"("pass_token"));



CREATE POLICY "visits_select_member" ON "public"."visits" FOR SELECT USING ("public"."is_member_of_project"(( SELECT "auth"."uid"() AS "uid"), "project_id"));



ALTER TABLE "public"."wallet_configs" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "wallet_configs member read" ON "public"."wallet_configs" FOR SELECT USING (("public"."is_superadmin"() OR "public"."is_member_of"(("project_id")::"uuid")));



ALTER TABLE "public"."wallet_configs_history" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "wallet_configs_member_insert" ON "public"."wallet_configs" FOR INSERT WITH CHECK (true);



CREATE POLICY "wallet_configs_member_select" ON "public"."wallet_configs" FOR SELECT USING ("public"."is_member_of_project"(( SELECT "auth"."uid"() AS "uid"), ("project_id")::"uuid"));



CREATE POLICY "wallet_configs_member_update" ON "public"."wallet_configs" FOR UPDATE USING ("public"."is_member_of_project"(( SELECT "auth"."uid"() AS "uid"), ("project_id")::"uuid"));



CREATE POLICY "wallet_configs_select" ON "public"."wallet_configs" FOR SELECT USING (true);



CREATE POLICY "wallet_cud" ON "public"."wallet_configs" USING ("public"."is_superadmin"());



CREATE POLICY "wallet_ins" ON "public"."wallet_configs" FOR INSERT WITH CHECK (true);



CREATE POLICY "wallet_insert" ON "public"."wallet_configs" FOR INSERT WITH CHECK (true);



ALTER TABLE "public"."wallet_links" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "wallet_links member read" ON "public"."wallet_links" FOR SELECT USING (("public"."is_superadmin"() OR "public"."is_member_of"("project_id")));



CREATE POLICY "wallet_links_member_insert" ON "public"."wallet_links" FOR INSERT WITH CHECK ("public"."is_member_of_project"(( SELECT "auth"."uid"() AS "uid"), "project_id"));



CREATE POLICY "wallet_links_member_select" ON "public"."wallet_links" FOR SELECT USING ("public"."is_member_of_project"(( SELECT "auth"."uid"() AS "uid"), "project_id"));



CREATE POLICY "wallet_read" ON "public"."wallet_configs" FOR SELECT USING (("public"."is_member_of_project"(("project_id")::"uuid") OR "public"."is_superadmin"()));



CREATE POLICY "wallet_select" ON "public"."wallet_configs" FOR SELECT USING (("public"."is_superadmin"() OR (EXISTS ( SELECT 1
   FROM "public"."project_members" "m"
  WHERE (("m"."project_id" = ("wallet_configs"."project_id")::"uuid") AND ("m"."user_id" = "auth"."uid"()))))));



ALTER TABLE "public"."wallet_templates" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "wallet_upd" ON "public"."wallet_configs" FOR UPDATE USING (("public"."is_member_of_project"(("project_id")::"uuid") OR "public"."is_superadmin"()));



CREATE POLICY "wallet_update" ON "public"."wallet_configs" FOR UPDATE USING ("public"."is_member_of_project"(("project_id")::"uuid"));



CREATE POLICY "wallet_update_superadmin" ON "public"."wallet_configs" FOR UPDATE USING ("public"."is_superadmin"());



CREATE POLICY "wallet_upsert" ON "public"."wallet_configs" FOR INSERT WITH CHECK (true);



CREATE POLICY "wallet_upsert_superadmin" ON "public"."wallet_configs" FOR INSERT WITH CHECK (true);



CREATE POLICY "wl_rw" ON "public"."wallet_links" TO "authenticated" USING (("public"."is_superadmin"() OR (EXISTS ( SELECT 1
   FROM "public"."project_members" "m"
  WHERE (("m"."project_id" = "wallet_links"."project_id") AND ("m"."user_id" = "auth"."uid"())))))) WITH CHECK (("public"."is_superadmin"() OR (EXISTS ( SELECT 1
   FROM "public"."project_members" "m"
  WHERE (("m"."project_id" = "wallet_links"."project_id") AND ("m"."user_id" = "auth"."uid"()))))));



GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";



GRANT ALL ON FUNCTION "public"."fn_find_user_id"("p_email" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."fn_find_user_id"("p_email" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_find_user_id"("p_email" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."fn_get_global_kpis"() TO "anon";
GRANT ALL ON FUNCTION "public"."fn_get_global_kpis"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_get_global_kpis"() TO "service_role";



GRANT ALL ON FUNCTION "public"."fn_get_global_kpis_timeseries"("p_months" integer) TO "anon";
GRANT ALL ON FUNCTION "public"."fn_get_global_kpis_timeseries"("p_months" integer) TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_get_global_kpis_timeseries"("p_months" integer) TO "service_role";



GRANT ALL ON FUNCTION "public"."fn_get_project_analytics"("p_project_id" "uuid", "p_start_date" timestamp with time zone, "p_end_date" timestamp with time zone) TO "anon";
GRANT ALL ON FUNCTION "public"."fn_get_project_analytics"("p_project_id" "uuid", "p_start_date" timestamp with time zone, "p_end_date" timestamp with time zone) TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_get_project_analytics"("p_project_id" "uuid", "p_start_date" timestamp with time zone, "p_end_date" timestamp with time zone) TO "service_role";



GRANT ALL ON FUNCTION "public"."fn_get_project_kpis"("p_project_id" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."fn_get_project_kpis"("p_project_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_get_project_kpis"("p_project_id" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."fn_get_project_kpis_timeseries"("p_project_id" "uuid", "p_months" integer) TO "anon";
GRANT ALL ON FUNCTION "public"."fn_get_project_kpis_timeseries"("p_project_id" "uuid", "p_months" integer) TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_get_project_kpis_timeseries"("p_project_id" "uuid", "p_months" integer) TO "service_role";



GRANT ALL ON FUNCTION "public"."fn_get_project_kpis_v2"("p_project_id" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."fn_get_project_kpis_v2"("p_project_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_get_project_kpis_v2"("p_project_id" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."fn_get_stats"("p_project" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."fn_get_stats"("p_project" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_get_stats"("p_project" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."fn_get_stats_all"() TO "anon";
GRANT ALL ON FUNCTION "public"."fn_get_stats_all"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_get_stats_all"() TO "service_role";



GRANT ALL ON FUNCTION "public"."fn_issuer_from_class"("p_class_id" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."fn_issuer_from_class"("p_class_id" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_issuer_from_class"("p_class_id" "text") TO "service_role";



REVOKE ALL ON FUNCTION "public"."fn_link_member_by_email"("p_email" "text", "p_project" "uuid", "p_role" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."fn_link_member_by_email"("p_email" "text", "p_project" "uuid", "p_role" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."fn_link_member_by_email"("p_email" "text", "p_project" "uuid", "p_role" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_link_member_by_email"("p_email" "text", "p_project" "uuid", "p_role" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."fn_list_customers_with_visits"("p_project_id" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."fn_list_customers_with_visits"("p_project_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_list_customers_with_visits"("p_project_id" "uuid") TO "service_role";



REVOKE ALL ON FUNCTION "public"."fn_list_members"("p_project" "uuid") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."fn_list_members"("p_project" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."fn_list_members"("p_project" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_list_members"("p_project" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."fn_list_visits"("p_project_id" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."fn_list_visits"("p_project_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_list_visits"("p_project_id" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."fn_scanner_visit"("p_project" "uuid", "p_google_sub" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."fn_scanner_visit"("p_project" "uuid", "p_google_sub" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_scanner_visit"("p_project" "uuid", "p_google_sub" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."fn_upsert_customer"("p_project" "uuid", "p_google_sub" "text", "p_email" "text", "p_name" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."fn_upsert_customer"("p_project_id" "uuid", "p_google_sub" "text", "p_name" "text", "p_email" "text", "p_avatar_url" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."fn_upsert_customer"("p_project_id" "uuid", "p_google_sub" "text", "p_name" "text", "p_email" "text", "p_avatar_url" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_upsert_customer"("p_project_id" "uuid", "p_google_sub" "text", "p_name" "text", "p_email" "text", "p_avatar_url" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."fn_upsert_customer_v2"("p_project_id" "uuid", "p_google_sub" "text", "p_name" "text", "p_email" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."fn_upsert_customer_v2"("p_project_id" "uuid", "p_google_sub" "text", "p_name" "text", "p_email" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_upsert_customer_v2"("p_project_id" "uuid", "p_google_sub" "text", "p_name" "text", "p_email" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."get_pass_owner"("p_token" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."get_wallet_link_and_customer_points"("p_project_id" "uuid", "p_google_sub" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."get_wallet_link_and_customer_points"("p_project_id" "uuid", "p_google_sub" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_wallet_link_and_customer_points"("p_project_id" "uuid", "p_google_sub" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."handle_new_auth_user"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_new_auth_user"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_new_auth_user"() TO "service_role";



GRANT ALL ON FUNCTION "public"."handle_new_user"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_new_user"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_new_user"() TO "service_role";



GRANT ALL ON FUNCTION "public"."is_member_of"("p_project" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."is_member_of"("p_project" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."is_member_of"("p_project" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."is_member_of_org"("p_user_id" "uuid", "p_org_id" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."is_member_of_org"("p_user_id" "uuid", "p_org_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."is_member_of_org"("p_user_id" "uuid", "p_org_id" "uuid") TO "service_role";



REVOKE ALL ON FUNCTION "public"."is_member_of_project"("p_project" "uuid") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."is_member_of_project"("p_project" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."is_member_of_project"("p_project" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."is_member_of_project"("p_project" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."is_member_of_project"("p_user" "uuid", "p_project" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."is_org_admin"("p_user_id" "uuid", "p_org_id" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."is_org_admin"("p_user_id" "uuid", "p_org_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."is_org_admin"("p_user_id" "uuid", "p_org_id" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."is_pass_belongs_to_current_user_by_token"("token_text" "text") TO "service_role";



REVOKE ALL ON FUNCTION "public"."is_superadmin"() FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."is_superadmin"() TO "anon";
GRANT ALL ON FUNCTION "public"."is_superadmin"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."is_superadmin"() TO "service_role";



GRANT ALL ON FUNCTION "public"."log_wallet_config_change"() TO "anon";
GRANT ALL ON FUNCTION "public"."log_wallet_config_change"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."log_wallet_config_change"() TO "service_role";



GRANT ALL ON FUNCTION "public"."prevent_multiple_sessions"() TO "anon";
GRANT ALL ON FUNCTION "public"."prevent_multiple_sessions"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."prevent_multiple_sessions"() TO "service_role";



GRANT ALL ON FUNCTION "public"."read_secret"("secret_name" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."read_secret"("secret_name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."read_secret"("secret_name" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."set_updated_at"() TO "anon";
GRANT ALL ON FUNCTION "public"."set_updated_at"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."set_updated_at"() TO "service_role";



REVOKE ALL ON FUNCTION "public"."update_wallet_link_google_object_id"("p_wallet_link_id" "uuid", "p_google_object_id" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."update_wallet_link_google_object_id"("p_wallet_link_id" "uuid", "p_google_object_id" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."update_wallet_link_google_object_id"("p_wallet_link_id" "uuid", "p_google_object_id" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_wallet_link_google_object_id"("p_wallet_link_id" "uuid", "p_google_object_id" "text") TO "service_role";



GRANT ALL ON TABLE "public"."clients" TO "anon";
GRANT ALL ON TABLE "public"."clients" TO "authenticated";
GRANT ALL ON TABLE "public"."clients" TO "service_role";



GRANT ALL ON TABLE "public"."customers" TO "anon";
GRANT ALL ON TABLE "public"."customers" TO "authenticated";
GRANT ALL ON TABLE "public"."customers" TO "service_role";



GRANT ALL ON TABLE "public"."events" TO "anon";
GRANT ALL ON TABLE "public"."events" TO "authenticated";
GRANT ALL ON TABLE "public"."events" TO "service_role";



GRANT ALL ON TABLE "public"."function_logs" TO "anon";
GRANT ALL ON TABLE "public"."function_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."function_logs" TO "service_role";



GRANT ALL ON TABLE "public"."locations" TO "anon";
GRANT ALL ON TABLE "public"."locations" TO "authenticated";
GRANT ALL ON TABLE "public"."locations" TO "service_role";



GRANT ALL ON TABLE "public"."loyalty_states" TO "anon";
GRANT ALL ON TABLE "public"."loyalty_states" TO "authenticated";
GRANT ALL ON TABLE "public"."loyalty_states" TO "service_role";



GRANT ALL ON TABLE "public"."notifications" TO "anon";
GRANT ALL ON TABLE "public"."notifications" TO "authenticated";
GRANT ALL ON TABLE "public"."notifications" TO "service_role";



GRANT ALL ON TABLE "public"."org_members" TO "anon";
GRANT ALL ON TABLE "public"."org_members" TO "authenticated";
GRANT ALL ON TABLE "public"."org_members" TO "service_role";



GRANT ALL ON TABLE "public"."orgs" TO "anon";
GRANT ALL ON TABLE "public"."orgs" TO "authenticated";
GRANT ALL ON TABLE "public"."orgs" TO "service_role";



GRANT ALL ON TABLE "public"."passes" TO "anon";
GRANT ALL ON TABLE "public"."passes" TO "authenticated";
GRANT ALL ON TABLE "public"."passes" TO "service_role";



GRANT ALL ON TABLE "public"."passkit_events" TO "anon";
GRANT ALL ON TABLE "public"."passkit_events" TO "authenticated";
GRANT ALL ON TABLE "public"."passkit_events" TO "service_role";



GRANT ALL ON TABLE "public"."profiles" TO "anon";
GRANT ALL ON TABLE "public"."profiles" TO "authenticated";
GRANT ALL ON TABLE "public"."profiles" TO "service_role";



GRANT ALL ON TABLE "public"."project_members" TO "anon";
GRANT ALL ON TABLE "public"."project_members" TO "authenticated";
GRANT ALL ON TABLE "public"."project_members" TO "service_role";



GRANT ALL ON TABLE "public"."project_wallets" TO "anon";
GRANT ALL ON TABLE "public"."project_wallets" TO "authenticated";
GRANT ALL ON TABLE "public"."project_wallets" TO "service_role";



GRANT ALL ON TABLE "public"."projects" TO "anon";
GRANT ALL ON TABLE "public"."projects" TO "authenticated";
GRANT ALL ON TABLE "public"."projects" TO "service_role";



GRANT ALL ON TABLE "public"."secrets" TO "anon";
GRANT ALL ON TABLE "public"."secrets" TO "authenticated";
GRANT ALL ON TABLE "public"."secrets" TO "service_role";



GRANT ALL ON TABLE "public"."user_passes" TO "anon";
GRANT ALL ON TABLE "public"."user_passes" TO "authenticated";
GRANT ALL ON TABLE "public"."user_passes" TO "service_role";



GRANT ALL ON TABLE "public"."user_wallets" TO "anon";
GRANT ALL ON TABLE "public"."user_wallets" TO "authenticated";
GRANT ALL ON TABLE "public"."user_wallets" TO "service_role";



GRANT ALL ON TABLE "public"."v_passes" TO "anon";
GRANT ALL ON TABLE "public"."v_passes" TO "authenticated";
GRANT ALL ON TABLE "public"."v_passes" TO "service_role";



GRANT ALL ON TABLE "public"."visits" TO "anon";
GRANT ALL ON TABLE "public"."visits" TO "authenticated";
GRANT ALL ON TABLE "public"."visits" TO "service_role";



GRANT ALL ON TABLE "public"."wallet_configs" TO "anon";
GRANT ALL ON TABLE "public"."wallet_configs" TO "authenticated";
GRANT ALL ON TABLE "public"."wallet_configs" TO "service_role";



GRANT ALL ON TABLE "public"."wallet_configs_history" TO "anon";
GRANT ALL ON TABLE "public"."wallet_configs_history" TO "authenticated";
GRANT ALL ON TABLE "public"."wallet_configs_history" TO "service_role";



GRANT ALL ON TABLE "public"."wallet_links" TO "anon";
GRANT ALL ON TABLE "public"."wallet_links" TO "authenticated";
GRANT ALL ON TABLE "public"."wallet_links" TO "service_role";



GRANT ALL ON TABLE "public"."wallet_templates" TO "anon";
GRANT ALL ON TABLE "public"."wallet_templates" TO "authenticated";
GRANT ALL ON TABLE "public"."wallet_templates" TO "service_role";



ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";







